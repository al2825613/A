package enums

type ExtractorType string

const (
	ExtractorTypeSingle ExtractorType = "single"
)
