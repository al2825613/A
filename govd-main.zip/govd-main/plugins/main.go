package plugins

import "govd/models"

var List = []models.Plugin{
	MergeAudio,
	SetID3,
}
